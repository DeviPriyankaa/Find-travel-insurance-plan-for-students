package policybazar.test;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utilities.ExtentManager;
import com.base.Driver;

public class BaseTest {
	    protected ExtentReports extent;
	    protected ExtentTest test;
	    Driver driver;


    @BeforeSuite
    public void setupReport() {
        extent = ExtentManager.getInstance();
    }
    

    @AfterSuite
    public void flushReport() {
        if (extent != null) {
            extent.flush(); 
        }
    }
}
