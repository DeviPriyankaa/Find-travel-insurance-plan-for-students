package policybazar.test;


import com.base.Driver;
import base.object.CarInsurancePage;
import utilities.ExtentManager;
import utilities.Screenshot;

import com.aventstack.extentreports.*;
import io.qameta.allure.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.*;

import java.io.File;
import java.time.Duration;

@Epic("PolicyBazaar Car Insurance")
@Feature("Car Insurance Form Validation")
public class CarInsuranceTest extends BaseTest {

    private static final Logger log = LogManager.getLogger(CarInsuranceTest.class);
    WebDriverWait wait;
    CarInsurancePage carPage;
    Screenshot screenshot;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setUp() {
        Driver.driver = new ChromeDriver();
        Driver.driver.manage().window().maximize();
        Driver.driver.get("https://www.policybazaar.com/");
        wait = new WebDriverWait(Driver.driver, Duration.ofSeconds(30));
        carPage = new CarInsurancePage(Driver.driver);
        screenshot = new Screenshot(Driver.driver);
        extent = ExtentManager.getInstance();
        test = extent.createTest("Car Insurance Test ");
        new File("screenshots").mkdirs();
        log.info("Test setup completed");
    }

    @Test(groups = {"sanity"},priority = 1)
    @Description("Verify navigation to Car Insurance section")
    public void TC11_verifyCarInsuranceNavigation() {
        log.info("Clicking Car Insurance link");
        carPage.clickCarInsuranceLink();
       String path=screenshot.takeScreenshot("TC11_verifyCarInsuranceNavigation");
        test.pass("Car Insurance navigation verified");
        //Allure.step("Car Insurance Navigation");
    }

    @Test(groups = {"sanity"},priority = 2)
    @Description("Verify error for empty car number")
    public void TC12_emptyCarNumberShowsError() throws InterruptedException {
    	Thread.sleep(2000);
        carPage.clickViewPrices();
        String error = carPage.getCarNumberError();
        log.warn("Error message: " + error);
        String path=screenshot.takeScreenshot("TC12_emptyCarNumberShowsError");
        test.pass("Empty car number error verified");
        //Allure.step("EmptyCarNumber shows Error");
    }

    @Test(groups = {"sanity"},priority = 3)
    @Description("Verify error for invalid car number")
    public void TC13_invalidCarNumberShowsError() throws InterruptedException {
    	Driver.driver.navigate().refresh();
    	Thread.sleep(2000);
        carPage.enterCarNumber("INVALID123");
        carPage.clickViewPrices();
        String error = carPage.getCarNumberError();
        log.warn("Error message: " + error);
        String path=screenshot.takeScreenshot("TC13_invalidCarNumberShowsError");
        test.pass("Invalid car number error verified");
        //Allure.step("Invalid Car Number Error Verified");
    }

    @Test(groups = {"sanity"},priority = 4)
    @Description("Verify error for special character input")
    public void TC15_invalidInputsShowError() throws InterruptedException {
    	Driver.driver.navigate().refresh();
    	Thread.sleep(2000);
        carPage.enterCarNumber("###123###");
        carPage.clickViewPrices();
        String error = carPage.getCarNumberError();
        log.warn("Error message: " + error);
        String path=screenshot.takeScreenshot("TC15_invalidInputsShowError");
        test.pass("Special character input error verified");
        //Allure.step("Special character input error verified");
    }

    @Test(groups = {"sanity"},priority = 5)
    @Description("Verify error for invalid mobile number")
    public void TC14_invalidPhoneNumberShowsError() throws InterruptedException {
    	Driver.driver.navigate().refresh();
    	Thread.sleep(2000);
        carPage.enterCarNumber("TS12SD1687");
        carPage.clickClickHereLink();
        Thread.sleep(2000);
        carPage.selectCarOption1();
        Thread.sleep(2000);
        carPage.selectCarOption2();
        Thread.sleep(2000);
        carPage.selectCarOption3();
        Thread.sleep(2000);
        carPage.selectCarOption3();
        Thread.sleep(2000);
        carPage.selectCarOption2();
        Thread.sleep(2000);
        carPage.enterMobileNumber("7657");
        String error = carPage.getMobileError();
        log.warn("Mobile error: " + error);
        String path=screenshot.takeScreenshot("TC14_invalidPhoneNumberShowsError");
        test.pass("Invalid mobile number error verified");
        //Allure.step("Invalid mobile number error verified");
    }

    @Test(groups = {"sanity"},priority = 6)
    @Description("Verify form submission with valid details")
    public void TC16_validDetailsProceed() throws InterruptedException {
    	Driver.driver.navigate().refresh();
    	Thread.sleep(2000);
        carPage.enterName("John");
        carPage.enterMobileNumber("7687586868");
        carPage.clickViewPrices();
        String path=screenshot.takeScreenshot("TC16_validDetailsProceed");
        test.pass("Valid details submitted successfully");
        //Allure.step("Valid details submitted successfully");
    }

    @AfterClass
    public void tearDown() {
        
        Driver.driver.quit();
        log.info("Test execution completed and browser closed");
    }
}

