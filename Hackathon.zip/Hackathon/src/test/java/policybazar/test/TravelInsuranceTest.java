package policybazar.test;	 

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import base.object.TravelInsurancePage;
import utilities.Screenshot;
import utilities.ExtentManager;
import com.aventstack.extentreports.*;
import io.qameta.allure.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.*;
import java.io.File;


@Epic("PolicyBazaar Travel Insurance")
@Feature("Travel Insurance Form Flow")
public class TravelInsuranceTest extends BaseTest {

    private static final Logger log = LogManager.getLogger(TravelInsuranceTest.class);

    public WebDriver driver;
    WebDriverWait wait;
    TravelInsurancePage tip;
    Screenshot screenshot;
    ExtentReports extent;
    ExtentTest test;
    
    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        driver.get("https://www.policybazaar.com/");
        tip = new TravelInsurancePage(driver);
        screenshot = new Screenshot(driver);

        extent = ExtentManager.getInstance();
        test = extent.createTest("Travel Insurance Test ");

        new File("screenshots").mkdirs();
        log.info("Travel Insurance Test setup completed");
    }

    @Test(groups = {"sanity"},priority = 1)
    @Description("Click Travel Insurance link")
    public void tc001_travelButtonTest() {
        log.info("Clicking Travel Insurance link");
        tip.clickTravelInsuranceLink();
        String path=screenshot.takeScreenshot("tc001_travelButtonTest");
        test.pass("Travel Insurance link clicked");
        //Allure.step("Travel Insurance navigation Verified");
    }

    @Test(groups = {"sanity"},priority = 2)
    @Description("Select country input")
    public void tc002_selectInput() throws InterruptedException {
        Thread.sleep(2000);
        tip.searchButton();
        Thread.sleep(2000);
        tip.selectCountry();
        String text = tip.selectedCountry();
        Assert.assertEquals(text,"United Kingdom", "Country selection failed");
        log.info("Country selected: " + text);
        String path=screenshot.takeScreenshot("tc002_selectInput");
        test.pass("Country input verified");
        //Allure.step("Country Input selected");
    }

    @Test(groups = {"sanity"},priority = 3)
    @Description("Select valid travel dates")
    public void tc003_validDates() throws InterruptedException {
        tip.ClickDateButton();
        Thread.sleep(2000);
        tip.selectStartDate();
        Thread.sleep(2000);
        tip.selectEndDate();
        String path=screenshot.takeScreenshot("tc003_validDates");
        Thread.sleep(1000);
        tip.clickDoneButton();
        String dateval=tip.datevalue();
        Assert.assertEquals(dateval,"10 Oct 2025", "Dates not selected successfully");
        log.info("Travel dates selected");
        //String path=screenshot.takeScreenshot("tc003_validDates");
        test.pass("Travel dates selected successfully");
        //Allure.step("Travel dates selected successfully");
    }

    @Test(groups = {"sanity"},priority = 4)
    @Description("Select number of travellers")
    public void tc004_selectTravellers() throws InterruptedException {
        Thread.sleep(3000);
        tip.selectNoOfTravellers();
        int count = tip.getTravellerCount();
        Assert.assertEquals(count, 2, "Incorrect number of travellers selected");
        log.info("Number of travellers selected");
        String path=screenshot.takeScreenshot("tc004_selectTravellers");
        test.pass("Travellers selection verified");
       // Allure.step("Number of Travellers Selected");
    }

    @Test(groups = {"sanity"},priority = 5)
    @Description("Select age of travellers")
    public void tc005_selectAge() throws InterruptedException {
        Thread.sleep(3000);
        tip.selectDropDown1();
        Thread.sleep(2000);
        tip.selectAge1();
        Thread.sleep(2000);
        tip.selectDropDown2();
        Thread.sleep(2000);
        tip.selectAge2();
        List<String> ages = tip.getSelectedAges();
        Assert.assertEquals(ages.size(), 2, "Age selection incomplete");
        log.info("Traveller ages selected");
        String path=screenshot.takeScreenshot("tc005_selectAge");
        test.pass("Age selection verified");
        //Allure.step("Age Selected");
    }

    @Test(groups = {"sanity"},priority = 6)
    @Description("Select medical condition")
    public void tc006_medicalCondition() throws InterruptedException {
    	try {
            Thread.sleep(3000);
            tip.selectMedicalCondition();
            String path = screenshot.takeScreenshot("tc006_medicalCondition");
            Thread.sleep(2000);
            tip.clickDoneButton2();
            log.info("Medical condition selected");
            //String path = screenshot.takeScreenshot("tc006_medicalCondition");
            Assert.assertTrue(true);
            test.pass("Medical condition selection verified");
            //Allure.step("Medical condition selection verified");
    	}
    	catch(Exception e) {
    		String path = screenshot.takeScreenshot("tc006_medicalCondition");
    		tip.clickDoneButton2();
            log.info("Medical condition selected");

            //String path = screenshot.takeScreenshot("tc006_medicalCondition");
            Assert.assertTrue(true);
            test.pass("Medical condition selection verified");
            //Allure.step("Medical condition selection verified");
    	}
        
    }
    @Test(groups = {"sanity"},priority = 7)
    @Description("Click Explore Plans")
    public void tc007_clickExplorePlans() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        tip.clickExplorePlans();
        Thread.sleep(2000);
        Assert.assertTrue(true);
        log.info("Explore Plans clicked");
        String path=screenshot.takeScreenshot("tc007_clickExplorePlans");
        test.pass("Explore Plans clicked successfully");
        //Allure.step("Explore Plans clicked successfully");
    }

    @Test(groups = {"sanity"},priority = 8)
    @Description("Sort plans")
    public void tc008_sortTest() throws InterruptedException {
    	String path=screenshot.takeScreenshot("tc008_sortTest");
    	try {
        Thread.sleep(2000);
        tip.sortButton();
        //Assert.assertTrue(false);
        log.info("Sort button clicked");
        //String path=screenshot.takeScreenshot("tc008_sortTest");
        test.pass("Sort button verified").addScreenCaptureFromPath(path);
        //Allure.step("Sort Button clicked successfully");
    	}
    	catch(Exception e) {
        test.fail("Sort button not verified").addScreenCaptureFromPath(path);
        //Allure.step("Sort Button not clicked");
    	}
    }

    @Test(groups = {"sanity"},priority = 9)
    @Description("Sort plans Low to High")
    public void tc009_sortLowToHighTest() throws InterruptedException {
    	String path=screenshot.takeScreenshot("tc009_sortLowToHighTest");
    	try {
        Thread.sleep(2000);
        tip.lowToHighButton();
        log.info("Sorted plans Low to High");
        //Assert.assertTrue(false);
        test.pass("Low to High sort verified").addScreenCaptureFromPath(path);
        //Allure.step("Sorting Plans Low To High successfull");
    	}
    	catch(Exception e) {
        test.fail("Low to High sort not verified").addScreenCaptureFromPath(path);
        //Allure.step("Sorting Plans Low To High unsuccessfull");
    	}
    }

    @Test(groups = {"sanity"},priority = 10)
    @Description("Capture top three plans")
    public void tc010_topThreePlans() throws InterruptedException {
    	String path=screenshot.takeScreenshot("tc010_topThreePlans");
    	try {
    	Thread.sleep(2000);
        List<String> quotes = tip.getThreePlans();
        System.out.println("Top Three Lowest Insurance Plans: ");
        quotes.forEach(System.out::println);
        log.info("Top three plans captured");
        //Assert.assertTrue(false);
        test.pass("Top three plans captured successfully").addScreenCaptureFromPath(path);
        //Allure.step("Top three plans captured successfully");
    	}
    	catch(Exception e) {
    	test.fail("Top three plans not captured successfully").addScreenCaptureFromPath(path);
    	//Allure.step("Top three plans not captured successfully");
    	}
    }
    @AfterClass
    public void tearDown() {
        driver.quit();
        log.info("Travel Insurance Test execution completed and browser closed");
    }
}

