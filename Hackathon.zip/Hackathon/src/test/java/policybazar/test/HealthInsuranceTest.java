package policybazar.test;

import com.base.Driver;
import base.object.HealthInsurancePage;
import utilities.ExtentManager;
import utilities.Screenshot;

import com.aventstack.extentreports.*;
import io.qameta.allure.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.*;

import java.io.File;
import java.time.Duration;
import java.util.List;

@Epic("PolicyBazaar Health Insurance")
@Feature("Health Insurance Menu Validation")
public class HealthInsuranceTest extends BaseTest {

    private static final Logger log = LogManager.getLogger(HealthInsuranceTest.class);

    WebDriverWait wait;
    HealthInsurancePage hp;
    Screenshot screenshot;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setUp() {
        Driver.driver = new ChromeDriver();
        Driver.driver.manage().window().maximize();
        Driver.driver.get("https://www.policybazaar.com/");
        wait = new WebDriverWait(Driver.driver, Duration.ofSeconds(30));

        hp = new HealthInsurancePage(Driver.driver);
        screenshot = new Screenshot(Driver.driver);

        extent = ExtentManager.getInstance();
        test = extent.createTest("Health Insurance Test ");

        new File("screenshots").mkdirs();
        log.info("Health Insurance Test setup completed");
    }

    @Test(groups = {"sanity"},priority = 1)
    @Description("Navigate to Health Insurance section")
    public void TC017_healthInsuranceNavigation() {
        log.info("Clicking Health Insurance section");
        String path=screenshot.takeScreenshot("TC017_healthInsuranceNavigation");
        hp.click();
       // String path=screenshot.takeScreenshot("TC017_healthInsuranceNavigation");
        test.pass("Health Insurance navigation verified");
        //Allure.step("Health Insurance navigation Verified");
    }

    @Test(groups = {"sanity"},priority = 2)
    @Description("Verify Health Insurance menu items are displayed")
    public void TC018_verifyMenuItems() {
        log.info("Fetching Health Insurance menu items");
        List<String> menuItems = hp.getMenuItems();
        assert !menuItems.isEmpty() : "Menu items are not displayed.";
        log.info("Menu items found: " + menuItems.size());
        test.pass("Menu items display verified");
        //Allure.step("Health Insurance Menu Items displayed");
    }

    @Test(groups = {"sanity"},priority = 3)
    @Description("Verify Health Insurance menu items are stored")
    public void TC019_verifyItemsStored() {
        log.info("Verifying menu items are stored");
        List<String> menuItems = hp.getMenuItems();
        assert menuItems.size() > 0 : "Menu items are not stored.";
        log.info("Stored menu items count: " + menuItems.size());
        test.pass("Menu items storage verified");
        //Allure.step("Menu Items Stored Successfully");
    }

    @Test(groups = {"sanity"},priority = 4)
    @Description("Print Health Insurance menu items")
    public void TC020_printMenuItems() {
        log.info("Printing Health Insurance menu items");
        List<String> menuItems = hp.getMenuItems();
        System.out.println("Health Insurance Menu items:");
        menuItems.forEach(System.out::println);
        log.info("Printed " + menuItems.size() + " menu items");
        String path=screenshot.takeScreenshot("TC020_printMenuItems");
        test.pass("Menu items printed successfully");
        //Allure.step("Printed Health Insurance Menu Items");
    }

    @AfterClass
    public void tearDown() {
      
        Driver.driver.quit();
        log.info("Health Insurance Test execution completed and browser closed");
    }
}

