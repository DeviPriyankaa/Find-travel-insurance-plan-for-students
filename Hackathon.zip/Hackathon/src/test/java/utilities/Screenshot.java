package utilities;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import io.qameta.allure.Allure;

public class Screenshot {
    private final WebDriver driver;

    public Screenshot(WebDriver driver) {
        this.driver = driver;
        ensureScreenshotFolderExists();
    }

    /**
     * Captures a screenshot and returns the absolute path for ExtentReports.
     * Also attaches the screenshot to Allure.
     *
     * @param testName Name of the test method or scenario
     * @return Absolute path to the saved screenshot
     */
    public String takeScreenshot(String testName) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File dest = new File("screenshots/" + testName + ".png");

        try {
        	Files.copy(src.toPath(), dest.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);


            // Attach to Allure
            Allure.addAttachment(testName, new String(Files.readAllBytes(dest.toPath())));

        } catch (IOException e) {
        	e.printStackTrace();
        }

        return dest.getAbsolutePath(); // For ExtentReports
    }

    /**
     * Ensures the screenshots folder exists.
     */
    private void ensureScreenshotFolderExists() {
        File folder = new File("screenshots");
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }
}

