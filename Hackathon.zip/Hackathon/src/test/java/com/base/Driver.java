package com.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Driver {
	public static WebDriver driver;

    public Driver(WebDriver driver) {
        Driver.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public static WebDriver getDriver() {
        return driver;

}
}
