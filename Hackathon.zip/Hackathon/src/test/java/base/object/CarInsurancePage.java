package base.object;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.base.Driver;

public class CarInsurancePage extends Driver{
	
	public CarInsurancePage(WebDriver driver) {
		super(driver);
	}


	    // Locators
	    @FindBy(xpath = "//p[contains(text(),'Car')]")
	    private WebElement carInsuranceLink;

	    @FindBy(xpath = "//button[text()='View Prices ']")
	    public WebElement viewPricesButton;

	    @FindBy(id = "regNoTextBox")
	    private WebElement carNumberInput;

	    @FindBy(xpath = "//p[text()='Please enter a valid car number']")
	    private WebElement carNumberError;

	    @FindBy(xpath = "//span[text()='Click here ']")
	    private WebElement clickHereLink;

	    @FindBy(xpath = "//div[@class='slideToLeft']/ul[1]/li[1]")
	    private WebElement carOption1;

	    @FindBy(xpath = "//div[@class='animationWrap']/ul/li[2]")
	    private WebElement carOption2;

	    @FindBy(xpath = "//div[@class='animationWrap']/ul/li[1]")
	    private WebElement carOption3;

	    //@FindBy(xpath = "//div[@class='animationWrap']/ul/li[2]")
	    //private WebElement carOption4;

	    @FindBy(id = "mobile-form-control")
	    private WebElement mobileInput;

	    @FindBy(xpath = "//div[text()='Enter a valid mobile number']")
	    private WebElement mobileError;

	    @FindBy(id = "name-form-control")
	    private WebElement nameInput;

	    // Actions
	    public void clickCarInsuranceLink() {
	        carInsuranceLink.click();
	    }

	    public void clickViewPrices() {
	        viewPricesButton.click();
	    }

	    public void enterCarNumber(String carNumber) {
	        carNumberInput.sendKeys(carNumber);
	    }

	    public String getCarNumberError() {
	        return carNumberError.getText();
	    }

	    public void clickClickHereLink() {
	        clickHereLink.click();
	    }

	    public void selectCarOption1() {
	        carOption1.click();
	    }

	    public void selectCarOption2() {
	        carOption2.click();
	    }

	    public void selectCarOption3() {
	        carOption3.click();
	    }

	    //public void selectCarOption4() {
	      //  carOption4.click();
	    //}

	    public void enterMobileNumber(String mobile) {
	        mobileInput.sendKeys(mobile);
	    }

	    public String getMobileError() {
	        return mobileError.getText();
	    }

	    public void enterName(String name) {
	        nameInput.sendKeys(name);
	    }
	}
