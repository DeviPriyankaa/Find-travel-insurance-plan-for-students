package base.object;
 import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.base.Driver;
	 
	public class TravelInsurancePage extends Driver{
		public TravelInsurancePage(WebDriver driver) {
			super(driver);
		}

		WebDriver driver;

	    
	    @FindBy(xpath = "//p[contains(text(),'Travel')]")
	    private WebElement travelInsuranceLink;
		
		@FindBy(xpath="//div[@class='inputRow']")
		public WebElement searchButton;
		
		@FindBy(xpath="//li[text()='United Kingdom']")
		public WebElement selectCountry;
		
		@FindBy(xpath="//span[text()='Start date ']")
		public WebElement dateButton;
		
		@FindBy(xpath="//button[@aria-label='Oct 10, 2025']")
		public WebElement startDate;
		
		@FindBy(xpath="//button[@aria-label='Nov 10, 2025']")
		public WebElement endDate;
		
		@FindBy(xpath="//button[text()='Continue']")
		public WebElement doneButton;
		
		@FindBy(xpath="//a[text()='travellers']")
		public WebElement addTravellers;
		
		@FindBy(xpath="//label[text()='2']")
		public WebElement noOfTravellers;
		
		@FindBy(xpath="//div[@id='divarrow_undefined'][1]")
		public WebElement dropDown1;
		
		@FindBy(xpath="//label[text()='21 years']")
		public WebElement age1;
		
		@FindBy(xpath="//div[text()='Select age of traveller 2']")
		public WebElement dropDown2;
		
		@FindBy(xpath="//label[text()='22 years']")
		public WebElement age2;
		
		@FindBy(xpath="//input[@id='ped_no' and @name='ped']")
		public WebElement medicalCondition;
		
		@FindBy(xpath="//button[text()='Done']")
		public WebElement doneButton2;
		
		@FindBy(xpath="//button[text()='Explore Plans ›']")
		public WebElement explorePlans;
	
	    @FindBy(xpath = "//p[text()='Sort by']")
	    private WebElement sortElement;
	    
	    @FindBy(xpath="//*[@id=\"17_sort\"]")
	    private WebElement sortLowToHigh;
	    
	    @FindBy(xpath="//article[@class='quotesCardWrapper '][position() <= 3]")
	    private List<WebElement> topThreePlans;
	    
	    @FindBy(xpath="//div[@class='newPq_duration_wrap__dateCol'][1]/p/em")
	    private WebElement date;
	    
	    @FindBy(id="0")
	    private WebElement ageOne;
	    
	    @FindBy(id="1")
	    private WebElement ageTwo; 
	    
	    @FindBy(xpath="//div[@class='selectedCountryWrap']")
	    private WebElement selectedCountry;
	    
	    public int getTravellerCount() {
	        String countText = noOfTravellers.getText();
	        return Integer.parseInt(countText);
	    }
		
	    public String datevalue() {
	    	 return date.getText();
	    }
	    public String selectedCountry() {
	    	return selectedCountry.getText();
	    }
	    
		public void clickTravelInsuranceLink() {
	        travelInsuranceLink.click();
	    }
		public void searchButton() {
			searchButton.click();
		}
		public void selectCountry(){
			selectCountry.click();
		}
		public void ClickDateButton() {
			dateButton.click();
		}
		public void selectStartDate() {
			startDate.click();
		}
		public void selectEndDate() {
			endDate.click();
		}
		public void clickDoneButton() {
			doneButton.click();
		}
		public void clickAddTravellers() {
			addTravellers.click();
		}
		public void selectNoOfTravellers() {
			noOfTravellers.click();
		}
		public void selectDropDown1(){
			dropDown1.click();
		}
		public void selectAge1() {
			age1.click();
		}
		public void selectDropDown2(){
			dropDown2.click();
		}
		public void selectAge2() {
			age2.click();
		}
		
		public List<String> getSelectedAges() {
	        List<String> ages = new ArrayList<>();
	        String age1 = ageOne.getText();
	        String age2 = ageTwo.getText();
	        ages.add(age1);
	        ages.add(age2);
	        return ages;
	    }
		public void selectMedicalCondition() {
			medicalCondition.click();
		}
		public void clickDoneButton2() {
			doneButton2.click();
		}
		public void clickExplorePlans() {
			explorePlans.click();
		}

	   public void sortButton() {
		   sortElement.click();
	   }
	   
	   public void lowToHighButton() {
		   sortLowToHigh.click();
	   }
	   
	   public List<String> getThreePlans(){
	    	List<String> text=new ArrayList<>();
	    	for(WebElement item:topThreePlans) {
	    		text.add(item.getText());
	    	}
	    	return text;
	    }
		
	}
	 



