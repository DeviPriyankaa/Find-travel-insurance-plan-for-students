package base.object;

import java.util.ArrayList;
import java.util.List;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import com.base.Driver;
 
public class HealthInsurancePage extends Driver{
	
	public HealthInsurancePage(WebDriver driver) {
		super(driver);
		
	}
	@FindBy(xpath="(//nav//a[contains(normalize-space(.),'Insurance Products')]" +
            " | //a[(starts-with(@href,'javascript') or @href='#' or contains(@href,'void'))" +
            " and contains(normalize-space(.),'Insurance Products')])[1]")
	 public WebElement insuranceProduct;
	
	@FindBy(xpath="//h3[contains(@class,'ruby-list-heading')]/a[normalize-space()='Health Insurance']")
	 public WebElement healthInsuranceLink;
	
	//@FindBy(xpath="//div[@class='ruby-col-3 hidden-md'][2]")
	//public WebElement healthCloumn;
	
    @FindBy(xpath="//div[@class='ruby-col-3 hidden-md'][2]")
    public List<WebElement> items;
	
    
	public void click() {
		Actions actions=new Actions(driver);
		 actions.moveToElement(insuranceProduct).perform();
	 }
    public List<String> getMenuItems(){
    	List<String> text=new ArrayList<>();
    	for(WebElement item:items) {
    		text.add(item.getText());
    	}
    	return text;
    }
	
	
}
